const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static("public"));

app.set("view engine", "ejs");

mongoose.connect("mongodb://127.0.0.1:27017/carrosDB");


// =======================
// SCHEMAS
// =======================

const usuarioSchema = new mongoose.Schema({
    nome: String,
    login: String,
    senha: String
});

const carroSchema = new mongoose.Schema({
    marca: String,
    modelo: String,
    ano: Number,
    qtde_disponivel: Number
});

const Usuario = mongoose.model("Usuario", usuarioSchema);

const Carro = mongoose.model("Carro", carroSchema);


// =======================
// ROTAS
// =======================

app.get("/", (req, res) => {
    res.redirect("/projects");
});


// =======================
// PROJECTS
// =======================

app.get("/projects", (req, res) => {
    res.render("index");
});


// =======================
// USUARIO
// =======================

app.get("/cadastroUsuario", (req, res) => {
    res.render("cadastroUsuario");
});

app.post("/cadastroUsuario", async (req, res) => {

    const novoUsuario = new Usuario({
        nome: req.body.nome,
        login: req.body.login,
        senha: req.body.senha
    });

    await novoUsuario.save();

    res.redirect("/login");
});


// =======================
// LOGIN
// =======================

app.get("/login", (req, res) => {
    res.render("login");
});

app.post("/login", async (req, res) => {

    const usuario = await Usuario.findOne({
        login: req.body.login,
        senha: req.body.senha
    });

    if(usuario){
        res.redirect("/carros");
    }
    else{
        res.send("Login invalido");
    }
});


// =======================
// LISTAR CARROS
// =======================

app.get("/carros", async (req, res) => {

    const carros = await Carro.find();

    res.render("carros", {
        carros
    });
});


// =======================
// NOVO CARRO
// =======================

app.get("/novoCarro", (req, res) => {
    res.render("novoCarro");
});

app.post("/novoCarro", async (req, res) => {

    const novoCarro = new Carro({
        marca: req.body.marca,
        modelo: req.body.modelo,
        ano: req.body.ano,
        qtde_disponivel: req.body.qtde
    });

    await novoCarro.save();

    res.redirect("/carros");
});


// =======================
// REMOVER
// =======================

app.get("/remover/:id", async (req, res) => {

    await Carro.findByIdAndDelete(req.params.id);

    res.redirect("/carros");
});


// =======================
// EDITAR
// =======================

app.get("/editar/:id", async (req, res) => {

    const carro = await Carro.findById(req.params.id);

    res.render("editarCarro", {
        carro
    });
});

app.post("/editar/:id", async (req, res) => {

    await Carro.findByIdAndUpdate(req.params.id, {

        marca: req.body.marca,
        modelo: req.body.modelo,
        ano: req.body.ano,
        qtde_disponivel: req.body.qtde

    });

    res.redirect("/carros");
});


// =======================
// VENDER
// =======================

app.get("/vender/:id", async (req, res) => {

    const carro = await Carro.findById(req.params.id);

    if(carro.qtde_disponivel > 0){

        carro.qtde_disponivel--;

        await carro.save();
    }

    res.redirect("/carros");
});


// =======================
// SERVIDOR
// =======================

app.listen(80, () => {
    console.log("Servidor rodando na porta 80");
});